# 假设已预处理文本数据，得到语料库和词典
from gensim.models import LdaModel

# 训练LDA模型，设置n_components=3
lda_model = LdaModel(corpus=corpus, id2word=dictionary, num_topics=3, passes=10)

# 输出每个主题的Top-10关键词
for topic_id in range(lda_model.num_topics):
    topic_terms = lda_model.show_topic(topic_id, topn=10)
    print(f"主题 {topic_id + 1} 的关键词：")
    for term, weight in topic_terms:
        print(f"  {term}: {weight:.4f}")
    print()