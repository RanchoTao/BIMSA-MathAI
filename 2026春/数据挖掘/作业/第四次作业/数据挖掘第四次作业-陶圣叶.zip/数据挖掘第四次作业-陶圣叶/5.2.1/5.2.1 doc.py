docs = [
    "AI and machine learning are transforming industries",  # 文档0
    "Deep learning models need large datasets for training",
    "Natural language processing helps computers understand text",
    "Data science combines statistics and programming",     # 文档3
    "Reinforcement learning optimizes agent actions",
    "Computer vision detects objects in images",
    "Big data analytics requires scalable infrastructure",
    "Neural networks learn from labeled examples",
    "Unsupervised learning finds hidden patterns",
    "Supervised learning predicts target variables"
]
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# 生成Count向量
count_vec = CountVectorizer(stop_words='english')
count_matrix = count_vec.fit_transform(docs)
count_features = count_vec.get_feature_names_out()

# 生成TF - IDF向量
tfidf_vec = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf_vec.fit_transform(docs)
tfidf_features = tfidf_vec.get_feature_names_out()
def get_top_n(vec_matrix, feat_names, doc_idx, n=5):
    doc_vec = vec_matrix[doc_idx].toarray().flatten()
    top_idx = doc_vec.argsort()[-n:][::-1]
    return [(feat_names[i], doc_vec[i]) for i in top_idx]

count_doc0_top5 = get_top_n(count_matrix, count_features, 0)
count_doc3_top5 = get_top_n(count_matrix, count_features, 3)
print("文档0 Count Top - 5:", count_doc0_top5)
print("文档3 Count Top - 5:", count_doc3_top5)
tfidf_doc0_top5 = get_top_n(tfidf_matrix, tfidf_features, 0)
tfidf_doc3_top5 = get_top_n(tfidf_matrix, tfidf_features, 3)
print("文档0 TF - IDF Top - 5:", tfidf_doc0_top5)
print("文档3 TF - IDF Top - 5:", tfidf_doc3_top5)